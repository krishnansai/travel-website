let express=require('express');
let mongoose=require('mongoose');
let ejs=require('ejs');
let app=express();
let port =5000;


app.use(express.urlencoded({extended:true}));
app.set('view engine','ejs');
app.use(express.static('public'));

mongoose.connect('mongodb://localhost:27017/traveldb');

mongoose.connection.on('connected',()=>{
    console.log("mongodb is connected");
})

let regSchema={
    name:String,
    pswd:String,
    cpswd:String
}

let regmodel=mongoose.model('reg',regSchema);

let miniSchema={
    name:String,
    email:String,
    date:String,
    fromplace:String,
    toplace:String,
    wmobile:String,
    mobile:String,
    address:String
}

let minimodel=mongoose.model('mini',miniSchema);

app.get('/',(req,res)=>{
    res.render('index');
});

app.get('/form',(req,res)=>{
    res.render('form');
})

app.get('/login',(req,res)=>{
    res.render('login');
})

app.get('/reg',(req,res)=>{
    res.render('reg');
});

app.get('/ilogin',(req,res)=>{
    res.render('ilogin')
})

app.get('/ireg',(req,res)=>{
    res.render('ireg')
})

app.get('/adminreg',(req,res)=>{
    res.render('admin');
});

app.get('/sucess',(req,res)=>{
    res.render('sucess');
})

app.get('/aindex',(req,res)=>{
    res.render('aindex');
})

app.get('/dataform',(req,res)=>{
    minimodel.find({},(err,found)=>{
        if(!err){
            res.render('dataform',{data8:found})
        }else{
            console.log(err);
        }
    })
})

app.post('/login',(req,res)=>{
    let name=req.body.name;
    let pass=req.body.pswd;

    regmodel.findOne({"name":name},(err,found)=>{
        if(!err){
            if(found){
                if((found.name==name)&&(found.pswd==pass)){
                    res.redirect('/');
                }else{
                    res.redirect('/ilogin');
                }
            } 
        }else{
            res.redirect('/login');
        }
      
    })

});

app.post('/sucess',(req,res)=>{

    let name=req.body.name;
    let email=req.body.email;
    let date=req.body.date;
    let wmobile=req.body.wmobile;
    let mobile=req.body.mobile;
    let address=req.body.address;
    let fromplace=req.body.fromplace;
    let toplace=req.body.toplace;

    let minidocs=new minimodel({
        name:name,
        email:email,
        date:date,
        fromplace:fromplace,
        toplace:toplace,
        wmobile:wmobile,
        mobile:mobile,
        address:address
    });

    minidocs.save();
    res.redirect('/sucess');
});

app.post('/reg',(req,res)=>{

    regname=req.body.name;
    pswd=req.body.pswd;
    cpswd=req.body.cpswd;

    if(pswd==cpswd){

  let regdocs=new regmodel({
      name:regname,
      pswd:pswd,
      cpswd:cpswd
      
  }) ;

  regdocs.save();
  res.redirect('/login');
}else{
   res.redirect('/ireg')
}

  

  
})

app.post('/adminreg',(req,res)=>{
    let email=req.body.email;
    let pass=req.body.pass;
    if((email=="sakthimurugan@gmail.com")&&(pass=="12345")){
        res.redirect('/aindex');
    }else{
        res.redirect('/adminreg');
    }
})


app.post('/delete',(req,res)=>{
    let dele=req.body.checkbox;
    minimodel.findByIdAndDelete(dele,(err)=>{
        if(!err){
            console.log("deleted sucessfully");
            res.redirect('/dataform');
        }else{
            console.log(err);
        }
    })
    })


app.listen(port,()=>{
    console.log(`the server runs on ${port}`);
})