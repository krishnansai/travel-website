var $ = jQuery;
window.addEventListener('load', function() {
    var iframeWrapper = $('#widget-container');
    if (iframeWrapper.length) {
        var targetUrl = iframeWrapper.attr('data-targeturl');
        var targetHost = iframeWrapper.attr('data-targethost');
        var targetHeight = 325;
        var iframeObj = '<iframe id="booking-widget" src="' + targetUrl + '" width="100%" height="' + targetHeight + '" style="overflow: hidden;" loading="lazy" title="trip builder widget"></iframe>';
        iframeWrapper.append(iframeObj);
        window.addEventListener('message', function(event) {
            if (event.origin !== targetHost) return;
            if (event.data.height) {
                document.getElementById('booking-widget').height = event.data.height || targetHeight;
            }
        }, false);
    }
});